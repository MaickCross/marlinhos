package model;

import javafx.application.Platform;
import javafx.scene.control.Slider;
import javafx.scene.image.ImageView;


public class Aviao extends Thread {

  private ImageView imagemAviao;
  private double velocidadeAviao;
  private int posicaoAviao;
  private Slider sliderAviao;

/**************************************************************
  * Metodo: Aviao02
  * Funcao: construtor da classe Aviao02
  * Parametros: ImageView, SLider, int
  * Retorno:
  ***************************************************************/
  public Aviao(ImageView imagemAviao, Slider sliderAviao, int posicaoAviao) {
    this.imagemAviao = imagemAviao;
    this.sliderAviao = sliderAviao;
    this.posicaoAviao = posicaoAviao;

  }

  /**************************************************************
  * Metodo: run
  * Funcao: inicia a thread responsavel por executar em loop, as logicas de movimento do Aviao
  * Parametros: nulo
  * Retorno:
  ***************************************************************/
  @Override
  public void run() {
    while (true) {
      Platform.runLater(() -> MovimentarAviao(posicaoAviao)); //movimenta o aviao conforme a posicao definida pelo jogador
      try {
        sleep(80); //responsavel pela animatação
      } catch (InterruptedException e) {
        e.printStackTrace();
      }
    }
  }

  /**************************************************************
  * Metodo: MovimentarAviao
  * Funcao: Responsavel pela movimentação do aviao de acordo com as posicoes de inicio, o metodo chama a funcao relacionada a cada posicao de acordo com as escolhas do usuario
  * Parametros: nulo
  * Retorno:
  ***************************************************************/
public void MovimentarAviao(int posicionarAviao){


  switch (posicionarAviao){
  
    case 1:
    //posiciona o aviao 02 na posicao inferior direita
      moverAviao();
    break;
  
    case 2:
    //posiciona o aviao 01 na posicao inferior esquerda
      moverAviao02();
    break;

    case 3:
    //posiciona o aviao 02 na posicao superior direita
      moverAviao03();

    break;

    case 4:
    //posiciona o aviao 01 na posicao superior esquerda
      moverAviao04();

    break;
    }
  }

//metodos relacionados ao movimento dos Avioes:


  /**************************************************************
  * Metodo: moverAviao
  * Funcao: responsavel pela animacao do aviao que inicia na posicao inferior direita
  * Parametros: nulo
  * Retorno: nulo
  ***************************************************************/
  private void moverAviao() {

    ImageView aviao = this.getImagemAviao(); //variavel para o ImageView
    velocidadeAviao = sliderAviao.getValue(); //slider que define a velocidade do Aviao

    if (aviao.getLayoutY() > 580) { //Trilho duplo horizontal 03
      aviao.setRotate(0);
      aviao.setLayoutY(aviao.getLayoutY() - velocidadeAviao);
      
    } else if (aviao.getLayoutY() > 540) { //Trilho duplo diagonal <- 03
      aviao.setRotate(-45);
      aviao.setLayoutY(aviao.getLayoutY() - velocidadeAviao);
      aviao.setLayoutX(aviao.getLayoutX() - velocidadeAviao);

    } else if (aviao.getLayoutY() > 440) { //Trilho simples 02
      aviao.setRotate(0);
      aviao.setLayoutY(aviao.getLayoutY() - velocidadeAviao);

    } else if (aviao.getLayoutY() > 400) {  //Trilho duplo Diagonal -> 02
      aviao.setRotate(45);
      aviao.setLayoutY(aviao.getLayoutY() - velocidadeAviao);
      aviao.setLayoutX(aviao.getLayoutX() + velocidadeAviao);

    } else if (aviao.getLayoutY() > 280) { //Trilho duplo horizontal 02
      aviao.setRotate(0);
      aviao.setLayoutY(aviao.getLayoutY() - velocidadeAviao);

    } else if (aviao.getLayoutY() > 240) { //Trilho duplo diagonal <- 02
      aviao.setRotate(-45);
      aviao.setLayoutY(aviao.getLayoutY() - velocidadeAviao);
      aviao.setLayoutX(aviao.getLayoutX() - velocidadeAviao);

    } else if (aviao.getLayoutY() > 130) {  //Trilho simples 01
      aviao.setRotate(0);
      aviao.setLayoutY(aviao.getLayoutY() - velocidadeAviao);

    } else if (aviao.getLayoutY() > 90) { //Trilho duplo diagonal -> 01
      aviao.setRotate(45);
      aviao.setLayoutY(aviao.getLayoutY() - velocidadeAviao);
      aviao.setLayoutX(aviao.getLayoutX() + velocidadeAviao);

    } else if(aviao.getLayoutY() >= -50) { //Trilho duplo horizontal 01
      aviao.setRotate(0);
      aviao.setLayoutY(aviao.getLayoutY() - velocidadeAviao);

    }
      else if(aviao.getLayoutY() <= -50) { //Final do trajeto
        aviao.setRotate(0);
      aviao.setLayoutX(141); //Posiciona o aviao na coordenada X
      aviao.setLayoutY(681); //Posiciona o aviao na coordenada Y
    }
  }

  /**************************************************************
  * Metodo: moverAviao02
  * Funcao: responsavel pela animacao do aviao que inicia na posicao inferior esquerda
  * Parametros: nulo
  * Retorno: nulo
  ***************************************************************/
private void moverAviao02() {

  ImageView aviao = this.getImagemAviao(); //variavel para o ImageView
  velocidadeAviao = sliderAviao.getValue(); //slider que controla a velocidade

  if (aviao.getLayoutY() > 580) { //Trilho duplo horizontal 03
    aviao.setRotate(0);
    aviao.setLayoutY(aviao.getLayoutY() - velocidadeAviao);
    
  } else if (aviao.getLayoutY() > 540) { //Trilho duplo diagonal -> 03
    aviao.setRotate(45);
    aviao.setLayoutY(aviao.getLayoutY() - velocidadeAviao);
    aviao.setLayoutX(aviao.getLayoutX() + velocidadeAviao);

  } else if (aviao.getLayoutY() > 440) { //Trilho simples 02
    aviao.setRotate(0);
    aviao.setLayoutY(aviao.getLayoutY() - velocidadeAviao);

  } else if (aviao.getLayoutY() > 400) {  //Trilho duplo Diagonal <- 02
    aviao.setRotate(-45);
    aviao.setLayoutY(aviao.getLayoutY() - velocidadeAviao);
    aviao.setLayoutX(aviao.getLayoutX() - velocidadeAviao);

  } else if (aviao.getLayoutY() > 280) { //Trilho duplo horizontal 02
    aviao.setRotate(0);
    aviao.setLayoutY(aviao.getLayoutY() - velocidadeAviao);

  } else if (aviao.getLayoutY() > 240) { //Trilho duplo diagonal -> 02
    aviao.setRotate(45);
    aviao.setLayoutY(aviao.getLayoutY() - velocidadeAviao);
    aviao.setLayoutX(aviao.getLayoutX() + velocidadeAviao);

  } else if (aviao.getLayoutY() > 130) {  //Trilho simples 01
    aviao.setRotate(0);
    aviao.setLayoutY(aviao.getLayoutY() - velocidadeAviao);

  } else if (aviao.getLayoutY() > 90) { //Trilho duplo diagonal <- 01
    aviao.setRotate(-45);
    aviao.setLayoutY(aviao.getLayoutY() - velocidadeAviao);
    aviao.setLayoutX(aviao.getLayoutX() - velocidadeAviao);

  } else if(aviao.getLayoutY() >= -50) { //Trilho duplo horizontal 01
    aviao.setRotate(0);
    aviao.setLayoutY(aviao.getLayoutY() - velocidadeAviao);

  }
    else if(aviao.getLayoutY() <= -50) { //Final do Trajeto
      aviao.setRotate(0);
    aviao.setLayoutX(71); //Posiciona o aviao na coordenada X
    aviao.setLayoutY(681); //Posiciona o aviao na coordenada Y
  }
}

  /**************************************************************
  * Metodo: moverAviao03
  * Funcao: responsavel pela animacao do aviao que inicia na posicao superior direita
  * Parametros: nulo
  * Retorno: nulo
  ***************************************************************/
  private void moverAviao03() {

    ImageView aviao = this.getImagemAviao(); //variavel para o ImageView
    velocidadeAviao = sliderAviao.getValue(); //slider que controla a velocidade
  
    if (aviao.getLayoutY() < 90) { //Trilho duplo horizontal 01
      aviao.setRotate(180);
      aviao.setLayoutY(aviao.getLayoutY() + velocidadeAviao);
      
    } else if (aviao.getLayoutY() < 130) { //Trilho duplo diagonal <- 01
      aviao.setRotate(225);
      aviao.setLayoutY(aviao.getLayoutY() +velocidadeAviao);
      aviao.setLayoutX(aviao.getLayoutX() - velocidadeAviao);
  
    } else if (aviao.getLayoutY() < 240) { //Trilho simples 01
      aviao.setRotate(180);
      aviao.setLayoutY(aviao.getLayoutY() + velocidadeAviao);
  
    } else if (aviao.getLayoutY() < 280) {  //Trilho duplo Diagonal -> 02
      aviao.setRotate(135);
      aviao.setLayoutY(aviao.getLayoutY() + velocidadeAviao);
      aviao.setLayoutX(aviao.getLayoutX() + velocidadeAviao);
  
    } else if (aviao.getLayoutY() < 400) { //Trilho duplo horizontal 02
      aviao.setRotate(180);
      aviao.setLayoutY(aviao.getLayoutY() + velocidadeAviao);
  
    } else if (aviao.getLayoutY() < 440) { //Trilho duplo diagonal <- 02
      aviao.setRotate(225);
      aviao.setLayoutY(aviao.getLayoutY() + velocidadeAviao);
      aviao.setLayoutX(aviao.getLayoutX() - velocidadeAviao);
  
    } else if (aviao.getLayoutY() < 540) {  //Trilho simples 02
      aviao.setRotate(180);
      aviao.setLayoutY(aviao.getLayoutY() + velocidadeAviao);
  
    } else if (aviao.getLayoutY() < 580) { //Trilho duplo diagonal -> 03
      aviao.setRotate(135);
      aviao.setLayoutY(aviao.getLayoutY() + velocidadeAviao);
      aviao.setLayoutX(aviao.getLayoutX() + velocidadeAviao);
  
    } else if(aviao.getLayoutY() <= 750) { //Trilho duplo horizontal 03
      aviao.setRotate(180);
      aviao.setLayoutY(aviao.getLayoutY() + velocidadeAviao);
  
    }
      else if(aviao.getLayoutY() >= 750) { //Final do Trajeto
        aviao.setRotate(180);
      aviao.setLayoutX(141); //Posiciona o aviao na coordenada X
      aviao.setLayoutY(-20); //Posiciona o aviao na coordenada Y
    }
  }

  /**************************************************************
  * Metodo: moverAviao04
  * Funcao: responsavel pela animacao do aviao que inicia na posicao superior esquerda
  * Parametros: nulo
  * Retorno: nulo
  ***************************************************************/
  private void moverAviao04() {

    ImageView aviao = this.getImagemAviao(); //variavel para o ImageView
    velocidadeAviao = sliderAviao.getValue(); //slider que controla a velocidade
  
    if (aviao.getLayoutY() < 90) { //Trilho duplo horizontal 01
      aviao.setRotate(180);
      aviao.setLayoutY(aviao.getLayoutY() + velocidadeAviao);
      
    } else if (aviao.getLayoutY() < 130) { //Trilho duplo diagonal -> 01
      aviao.setRotate(135);
      aviao.setLayoutY(aviao.getLayoutY() +velocidadeAviao);
      aviao.setLayoutX(aviao.getLayoutX() + velocidadeAviao);
      
  
    } else if (aviao.getLayoutY() < 240) { //Trilho simples 01
      aviao.setRotate(180);
      aviao.setLayoutY(aviao.getLayoutY() + velocidadeAviao);
      
  
    } else if (aviao.getLayoutY() < 280) {  //Trilho duplo Diagonal <- 02
      aviao.setRotate(225);
      aviao.setLayoutY(aviao.getLayoutY() + velocidadeAviao);
      aviao.setLayoutX(aviao.getLayoutX() - velocidadeAviao);
  
    } else if (aviao.getLayoutY() < 400) { //Trilho duplo horizontal 02
      aviao.setRotate(180);
      aviao.setLayoutY(aviao.getLayoutY() + velocidadeAviao);
  
    } else if (aviao.getLayoutY() < 440) { //Trilho duplo diagonal -> 02
      aviao.setRotate(135);
      aviao.setLayoutY(aviao.getLayoutY() + velocidadeAviao);
      aviao.setLayoutX(aviao.getLayoutX() + velocidadeAviao);
  
    } else if (aviao.getLayoutY() < 540) {  //Trilho simples 02
      aviao.setRotate(180);
      aviao.setLayoutY(aviao.getLayoutY() + velocidadeAviao);
  
    } else if (aviao.getLayoutY() < 580) { //Trilho duplo diagonal <- 03
      aviao.setRotate(225);
      aviao.setLayoutY(aviao.getLayoutY() + velocidadeAviao);
      aviao.setLayoutX(aviao.getLayoutX() - velocidadeAviao);
  
    } else if(aviao.getLayoutY() <= 750) { //Trilho duplo horizontal 03
      aviao.setRotate(180);
      aviao.setLayoutY(aviao.getLayoutY() + velocidadeAviao);
  
    }
      else if(aviao.getLayoutY() >= 750) { //Final do Trajeto
        aviao.setRotate(180);
      aviao.setLayoutX(71); //Posiciona o aviao na coordenada X
      aviao.setLayoutY(-20); //Posiciona o aviao na coordenada Y
    }
  }








//Getters e Setters

  /**************************************************************
  * Metodo: getImagemAviao
  * Funcao: receber a imagem do aviao
  * Parametros: nulo
  * Retorno: ImageView
  ***************************************************************/
  public ImageView getImagemAviao() {
    return imagemAviao;
  }

  /**************************************************************
  * Metodo: setimagemAviao
  * Funcao: definir a imagem do aviao
  * Parametros: ImageView
  * Retorno: nulo
  ***************************************************************/
  public void setImagemAviao(ImageView imagemAviao) {
    this.imagemAviao = imagemAviao;
  }

  /**************************************************************
  * Metodo: getVelocidadeAviao
  * Funcao: receber a velocidade do Aviao
  * Parametros: nulo
  * Retorno: double
  ***************************************************************/
  public double getVelocidadeAviao() {
    return this.velocidadeAviao;
  }

  /**************************************************************
  * Metodo: setVelocidadeAviao
  * Funcao: definir a velocidade do Aviao
  * Parametros: double
  * Retorno: nulo
  ***************************************************************/
  public void setVelocidadeAviao(double velocidadeAviao) { 
    this.velocidadeAviao = velocidadeAviao;
  }

  /**************************************************************
  * Metodo: getPosicaoAviao
  * Funcao: receber a posicao do Aviao
  * Parametros: nulo
  * Retorno: int
  ***************************************************************/
  public int getposicaoAviao() {
    return this.posicaoAviao;
  }
  
  /**************************************************************
  * Metodo: setPosicaoAviao
  * Funcao: definir a posicao do Aviao
  * Parametros: int
  * Retorno: nulo
  ***************************************************************/
  public void setPosicaoAviao(int posicaoAviao){
    this.posicaoAviao = posicaoAviao;

  }
  //Fim dos Getters e Setters

}
