package model;

import controller.TelaCarregamentoController;
import javafx.application.Platform;
import javafx.scene.image.ImageView;

public class AviaoCarregamento extends Thread{

private ImageView imagemAviaoCarregamento;
private double velocidadeAviaoCarregamento;
private int posicaoAviaoCarregamento;

private TelaCarregamentoController controller;

private boolean continuar = true;


/**************************************************************
  * Metodo: AviaoCarregamento
  * Funcao: construtor da classe AviaoCarregamento
  * Parametros: ImageView
  * Retorno: ImageView
  ***************************************************************/
  public AviaoCarregamento(ImageView imagemAviaoCarregamento,   TelaCarregamentoController controller) {
    this.imagemAviaoCarregamento = imagemAviaoCarregamento;
    this.controller = controller;
  }

  public ImageView getImagemAviaoCarregamento(){
    return imagemAviaoCarregamento;
  }

  public void setImagemAviaoCarregamento(ImageView imagemAviaoCarregamento){
    this.imagemAviaoCarregamento = imagemAviaoCarregamento;
  }

  public double getVelocidadeAviaoCarregamento(){
    return this.velocidadeAviaoCarregamento;
  }

  public int getPosicaoAviaoCarregamento(){
    return this.posicaoAviaoCarregamento;
  }

  @Override
  public void run() {
    while (continuar) {
      Platform.runLater(() -> moverAviao()); 
      try {
        sleep(40);
      } catch (InterruptedException e) {
        e.printStackTrace();
      }
    }
  }


//x=-32 y=239


  // Método para mover o avião
private void moverAviao() {
  ImageView imagem = this.getImagemAviaoCarregamento();

  if (imagem.getLayoutX() < 170) {

      imagem.setLayoutX(imagem.getLayoutX() + 10);

  } else if(imagem.getLayoutX() < 280){

    imagem.setLayoutX(imagem.getLayoutX() + 8);
    imagem.setLayoutY(imagem.getLayoutY() + 2);
    
  }else if (imagem.getLayoutX() < 300) {

    imagem.setLayoutX(imagem.getLayoutX() + 10);

}else if(imagem.getLayoutX() < 400){

    imagem.setLayoutX(imagem.getLayoutX() + 8);
    imagem.setLayoutY(imagem.getLayoutY() - 2);

  }else if (imagem.getLayoutX() < 420) {

    imagem.setLayoutX(imagem.getLayoutX() + 10);

}else if(imagem.getLayoutX() < 540){

    imagem.setLayoutX(imagem.getLayoutX() + 8);
    imagem.setLayoutY(imagem.getLayoutY() + 2);
    
  }else if (imagem.getLayoutX() < 800) {

    imagem.setLayoutX(imagem.getLayoutX() + 10);

}else if (imagem.getLayoutX() >= 800) { // Quando chega ao destino final

    continuar = false; //para a thread
      Platform.runLater(() -> controller.TrocarTelaSimulacao()); // Chama na Thread correta
    
  }
}






  
}







