package controller;


import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Slider;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import model.Aviao;

public class TelaSimulacaoController {

    @FXML ImageView aviao01;
    @FXML ImageView aviao02;
    @FXML ImageView menuIcone;
    @FXML ImageView imagemRota;
    //@FXML ImageView botaoJogar;

    @FXML Slider sliderAviao02;
    @FXML Slider sliderAviao01;

    @FXML Button botao01;
    @FXML Button botao02;
    @FXML Button botao03;
    @FXML Button botao04;
    @FXML Button botaoReset;
    @FXML Button botaoRota;

    Aviao av2;
    Aviao av1;
    int posicaoInicial;

    private Scene cena;
    private Stage janela;

  
    @FXML
    public void initialize(){
      //aviao01
      av1 = new Aviao(aviao01, sliderAviao01, posicaoInicial=2);
      av1.start();

      //aviao02
      av2 = new Aviao(aviao02, sliderAviao02,posicaoInicial =1); 
      av2.start();
      
      
    }

  
    //METODO GET POSICAO INICIAL
    public int getPosicaoInicial(){
      return this.posicaoInicial;
    }


//botao 01, para ambos embaixo
public void Posicao01(ActionEvent event) throws IOException {

  av1.setPosicaoAviao(2);
  av2.setPosicaoAviao(1);

  aviao01.setLayoutX(71);
  aviao01.setLayoutY(681);

  aviao02.setLayoutX(141);
  aviao02.setLayoutY(681);

    }

//botao 02, para ambos encima
public void Posicao02(ActionEvent event) throws IOException { 

  av1.setPosicaoAviao(4);
  av2.setPosicaoAviao(3);

  aviao01.setLayoutX(71);
  aviao01.setLayoutY(-20);

  aviao02.setLayoutX(141);
  aviao02.setLayoutY(-20);
}

//botao 03, para aviao 01 encima e aviao 02 embaixo
public void Posicao03(ActionEvent event) throws IOException {

  av1.setPosicaoAviao(4);
  av2.setPosicaoAviao(1);

  aviao01.setLayoutX(71);
  aviao01.setLayoutY(-20);

  aviao02.setLayoutX(141);
  aviao02.setLayoutY(681);

}

//botao 04, para aviao 01 embaixo e aviao 02 encima
public void Posicao04(ActionEvent event) throws IOException {

  av1.setPosicaoAviao(2);
  av2.setPosicaoAviao(3);

  aviao01.setLayoutX(71);
  aviao01.setLayoutY(681);

  aviao02.setLayoutX(141);
  aviao02.setLayoutY(-20);

}

//Botao de reset que reseta a cena
public void Resetar(ActionEvent event) throws IOException {
        Parent raiz = FXMLLoader.load(getClass().getResource("/view/telaSimulacao.fxml"));
        janela = (Stage) ((Node) event.getSource()).getScene().getWindow();
        cena = new Scene(raiz);
        janela.setScene(cena);
        janela.show();

    }

    //BOTAO DE VOLTAR PARA O MENU
    public void Voltar(ActionEvent event) throws IOException {

      Parent raiz = FXMLLoader.load(getClass().getResource("/view/telaInicial.fxml"));
      janela = (Stage) ((Node) event.getSource()).getScene().getWindow();
      cena = new Scene(raiz);
      janela.setScene(cena);
      janela.show();
  }

  //BOTAO DE MOSTRAR A ROTA

  @FXML
    public void ExibirRota(ActionEvent event) throws IOException{
        if (imagemRota.isVisible()) {
            imagemRota.setVisible(false); // Torna a imagem invisível
        } else {
            imagemRota.setVisible(true); // Torna a imagem visível
        }
    }
  





}



