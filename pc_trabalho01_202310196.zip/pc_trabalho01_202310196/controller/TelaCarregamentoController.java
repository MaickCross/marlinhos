package controller;

import java.io.IOException;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import model.AviaoCarregamento;

public class TelaCarregamentoController {
    
    @FXML ImageView aviaoCarregamento;


    private AviaoCarregamento aviao;

    @FXML
    public void initialize(){

      aviao = new AviaoCarregamento(aviaoCarregamento, this);
      aviao.start();

      
      
    }

 
//trpcar a tela
@FXML
public void TrocarTelaSimulacao() {
    try {
        // Carregar a nova tela
        Parent raiz = FXMLLoader.load(getClass().getResource("/view/telaSimulacao.fxml"));

        // Obter a janela atual (Stage)
        Stage janelaAtual = (Stage) aviaoCarregamento.getScene().getWindow();

        // Criar a nova cena e atribuí-la à janela
        Scene novaCena = new Scene(raiz);
        janelaAtual.setScene(novaCena);
        janelaAtual.show();
    } catch (IOException e) {
        e.printStackTrace(); // Exibe o erro no console
    }
}


    
}
