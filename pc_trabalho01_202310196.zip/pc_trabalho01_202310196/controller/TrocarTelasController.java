package controller;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

public class TrocarTelasController {
    @FXML Button botaoJogar;
    @FXML Button botaoSairSobre;
    @FXML Button sobre;

    @FXML ImageView menuIcone;
    @FXML ImageView menuIcone02;
    
    private Stage janela;
    private Scene cena;

    
    //metodo da tela inicial para mudar para a tela de carregamento(loading)
    public void Jogar(ActionEvent event) throws IOException {
        //Parent raiz = FXMLLoader.load(getClass().getResource("/view/telaSimulacao.fxml"));
        Parent raiz = FXMLLoader.load(getClass().getResource("/view/telaCarregamento.fxml"));
        janela = (Stage) ((Node) event.getSource()).getScene().getWindow();
        cena = new Scene(raiz);
        janela.setScene(cena);
        janela.show();

    }

    //metodo da tela de carregamento para mudar para a tela de simulacao
    

    //metodo pra mostrar o icone jogar
    @FXML
public void MostrarIconeAviao(MouseEvent event) throws IOException {

        menuIcone.setVisible(true);
    
      }

      //remove o icone da tela jogar
public void RemoverIconeAviao(MouseEvent event) throws IOException {

    menuIcone.setVisible(false);
}

//voltar para tela inicial sobre
public void VoltarTelaInicialSobre(ActionEvent event) throws IOException {

    Parent raiz = FXMLLoader.load(getClass().getResource("/view/telaInicial.fxml"));
      janela = (Stage) ((Node) event.getSource()).getScene().getWindow();
      cena = new Scene(raiz);
      janela.setScene(cena);
      janela.show();
}

//metodo pra mostrar o icone sobre
@FXML
public void MostrarIconeAviaoSobre(MouseEvent event) throws IOException {

        menuIcone02.setVisible(true);
}

//remove o icone da tela jogar
public void RemoverIconeAviaoSobre(MouseEvent event) throws IOException {

    menuIcone02.setVisible(false);
}

//ir para tela sobre
public void telaSobre(ActionEvent event) throws IOException {

    Parent raiz = FXMLLoader.load(getClass().getResource("/view/telaSobre.fxml"));
      janela = (Stage) ((Node) event.getSource()).getScene().getWindow();
      cena = new Scene(raiz);
      janela.setScene(cena);
      janela.show();
}


    }



    
    

